# echo-client.py
from flask import Flask, render_template, request, redirect, url_for, session
import requests
import socket
import json
import os
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
#
# Returns: An rsa.RSAPrivateKey object (which contains both the private key
#   and its corresponding public key; use .public_key() to obtain it).
#


app = Flask(__name__)
name = 'AllarassemJJ20'
app.secret_key = name
RSA_KEY_BITS = 4096
RSA_PUBLIC_EXPONENT = 65537
def rsa_gen_keypair():
    return rsa.generate_private_key(
            key_size = RSA_KEY_BITS,
            public_exponent = RSA_PUBLIC_EXPONENT
            )

#
# Argument: An rsa.RSAPrivateKey object
#
# Returns: An ASCII/UTF-8 string serialization of the private key using the
#   PKCS-8 format and PEM encoding. Does not encrypt the key for at-rest
#   storage.
#


app = Flask(__name__)
name = 'AllarassemJJ20'
app.secret_key = name

    

@app.route('/')
def home():
    message = ""
    return render_template('/home.html', message=message)


@app.route('/receive')
def receive():
    files = []
    message = ""
    message = main_receive()
    files = [f for f in os.listdir('./uploads')]
    return render_template('/receive.html', files=files, message=message)

@app.route('/send', methods=['GET', 'POST'])
def send():
    if request.method == 'GET':
        return render_template('/send.html')
    if request.method == 'POST':
        # Check if the post request has the file part
        if 'fileInput' not in request.files:
            return render_template('send.html')

        file = request.files['fileInput']
        print('hello ', file)
        
        # If the user does not select a file, the browser submits an empty file without a filename
        if file.filename == '':
            return render_template('send.html')

        # Save the file to the server (you can customize the path)
        file.save('./uploads/' + file.filename)
        path = './uploads/' + file.filename
        message = main_send(path) 
        return render_template('/home.html', message=message)

def rsa_serialize_private_key(private_key:rsa.RSAPrivateKey):
    return private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    ).decode()

#
# Argument: A string containing an unencrypted RSA private key in PEM format.
#   Note that this also includes the matching public key (i.e., a PEM
#   "private key" serialization includes both halves of the keypair).
#
# Returns: An rsa.RSAPrivateKey object consisting of the deserialized key.
#
def rsa_deserialize_private_key(pem_privkey):
    return serialization.load_pem_private_key(pem_privkey.encode(),password=None)

#
# Argument: An rsa.RSAPublicKey object
#
# Returns: An ASCII/UTF-8 serialization of the public key using the
#   SubjectPublicKeyInfo format and PEM encoding.
#
def rsa_serialize_public_key(public_key:rsa.RSAPublicKey):
    return public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    ).decode() #decode default is UTF-8

#
# Argument: A string containing an RSA public key in PEM format.
#
# Returns: An rsa.RSAPublicKey object consisting of the deserialized key.
#
def rsa_deserialize_public_key(pem_pubkey):
    return serialization.load_pem_public_key(pem_pubkey.encode())

#
# Arguments:
#   public_key: An rsa.RSAPublicKey object containing the public key of the
#       message recipient.
#   plaintext: The plaintext message to be encrypted (as a raw byte string).
#
# Returns: The encrypted message (ciphertext), as a raw byte string.
#
def rsa_encrypt(public_key:rsa.RSAPublicKey, plaintext:bytes):
    #plaintext is bytes, public_key is the public key of the message recipient
    return public_key.encrypt(
        plaintext,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )

#
# Arguments:
#   private_key: An rsa.RSAPrivateKey object containing the private key of the
#       message recipient.
#   plaintext: The ciphertext message to be decrypted (as a raw byte string).
#
# Returns: The decrypted message (plaintext), as a raw byte string.
#
def rsa_decrypt(private_key:rsa.RSAPrivateKey, ciphertext:bytes):
    return private_key.decrypt(
        ciphertext,
        padding.OAEP(
        mgf=padding.MGF1(algorithm=hashes.SHA256()),
        algorithm=hashes.SHA256(),
        label=None
        )
    )

#
# Encrypts a plaintext message using AES-256 in CTR (Counter) mode.
#
# Arguments:
#   key: A 256-bit (32-byte) secret key. This should either be randomly
#       generated, or derived from a password using a secure key derivation
#       function.
#   nonce: A 128-bit (16-byte) nonce to use with CTR mode. It is imperative
#       that this be randomly generated, and NEVER reused after being used
#       once to encrypt a single message. (This is because each time you
#       encrypt a message with the same nonce in CTR mode, the counter starts
#       fresh from 0 again, meaning the initial blocks will have been XORed
#       with the same keystream as the previous message - allowing the key to
#       be trivially recovered by comparing the two.)
#           (N.B.: Even though we are using AES-256, i.e. a key size of 256
#           bits, the nonce is still 128 bits, because the block size of AES
#           is always 128 bits. A longer key just increases the number of
#           rounds performed.)
#   plaintext: The plaintext message to be encrypted (as a raw byte string).
#
# Returns: The encrypted message (ciphertext), as a raw byte string.
#
def aes_encrypt(key, nonce, plaintext):
    cipher = Cipher(algorithms.AES256(key),modes.CTR(nonce))
    e = cipher.encryptor()
    return e.update(plaintext) + e.finalize()

#
# Decrypts a plaintext message using AES-256 in CTR (Counter) mode.
#
# Arguments:
#   key: A 256-bit (32-byte) secret key.
#   nonce: A 128-bit (16-byte) nonce to use with CTR mode.
#   ciphertext: The ciphertext message to be decrypted (as a raw byte string).
#
# No restrictions are placed on the values of key and nonce, but obviously,
# if they don't match the ones used to encrypt the message, the result will
# be gibberish.
#
# Returns: The decrypted message (plaintext), as a raw byte string.
#
def aes_decrypt(key, nonce, ciphertext):
    cipher = Cipher(algorithms.AES256(key),modes.CTR(nonce))
    d = cipher.decryptor()
    return d.update(ciphertext) + d.finalize()

#
# Encrypts a plaintext message using AES-256-CTR using a randomly generated
# session key and nonce.
#
# Argument: The plaintext message to be encrypted (as a raw byte string).
#
# Returns: A tuple containing the following elements:
#   session_key: The randomly-generated 256-bit session key used to encrypt
#       the message (as a raw byte string).
#   nonce: The randomly-generated 128-bit nonce used in the encryption (as a
#       raw byte string).
#   ciphertext: The encrypted message (as a raw byte string).
#
def aes_encrypt_with_random_session_key(plaintext):
    key = os.urandom(32)
    nonce = os.urandom(16)
    return key,nonce,aes_encrypt(key,nonce,plaintext)

#
# Encrypt a message using AES-256-CTR and a random session key, which in turn
# is encrypted with RSA so that it can be decrypted by the given public key.
#
# Arguments:
#   public_key: An rsa.RSAPublicKey object containing the public key of the
#       message recipient.
#   plaintext: The plaintext message to be encrypted (as a raw byte string).
#
# Returns: A tuple containing the following elements:
#   encrypted_session_key: The randomly-generated AES session key, encrypted
#       using RSA with the given public key (as a raw byte string).
#   nonce: The randomly-generated nonce used in the AES-CTR encrpytion (as a
#       raw byte string).
#   ciphertext: The AES-256-CTR-encrypted message (as a raw byte string).
#
def encrypt_message_with_aes_and_rsa(public_key, plaintext):
    aesEncryptTuple = aes_encrypt_with_random_session_key(plaintext)
    #print(rsa_encrypt(public_key,aesEncryptTuple[0]))
    #print(aesEncryptTuple[1])
    #print(aesEncryptTuple[2])
    #sign before sending when doing finProject
    return rsa_encrypt(public_key,aesEncryptTuple[0]),aesEncryptTuple[1],aesEncryptTuple[2]

# Encrypt the message using AES-256-CTR and a random session key, then encrypt the random session key
# with RSA so that it can be decrypted by the given public key. Finally, sign the resulting message with
# the RSA private key to provide authentication. The result is a message where both confidentiality and
# integrity are preserved.
#
# Arguments:
#   private_key: An rsa.RSAPrivateKey object containing the private key that will be used to sign the encrypted message.
#   
#   public_key: An rsa.RSAPublicKey object containing the public key of the message recipient.
#   
#   plaintext: The plaintext message to be encrypted (as a raw byte string).
#
# Returns: a tuple containing first the RSA-encrypted session key, second the nonce used to encrypt, third the message
# encrypted with AES-256-CTR and the session key, and fourth an RSA byte signature of the encrypted session key, nonce, and encrypted message
def encrypt_message(private_key:rsa.RSAPrivateKey, public_key, plaintext:str):
    #If your data is too large to be passed in a single call, you can hash it separately and pass that value using Prehashed. Not sure if we'll run into this issue, but seems like a good note to have.
    encKey,nonce,encMes = encrypt_message_with_aes_and_rsa(public_key,plaintext.encode())
    return encKey,nonce,encMes, private_key.sign(
        #the following results in the string concatenation of the encrypted session key, nonce, and encrypted message in that order
        b"".join((encKey,nonce,encMes)),
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH
        ),
        hashes.SHA256()
    )

#
# Decrypt a message that has been encrypted with AES-256-CTR, using an
# RSA-encrypted session key and an unencrypted nonce.
#
# Arguments:
#   private_key: An rsa.RSAPrivateKey object containing the private key that
#       will be used to decrypt the session key.
#   encrypted_session_key: The RSA-encrypted session key that will be used to
#       decrypt the actual message with AES-256-CTR (as a raw byte string).
#   nonce: The nonce that will be used to decrypt the message with
#       AES-256-CTR (as a raw byte string).
#   ciphertext: The AES-256-CTR-encrypted message (as a raw byte string).
#
# Returns: The decrypted message (plaintext), as a raw byte string.
#
def decrypt_message_with_aes_and_rsa(private_key, encrypted_session_key, nonce, ciphertext):
    dsk = rsa_decrypt(private_key,encrypted_session_key)
    return aes_decrypt(dsk,nonce,ciphertext)

# Verify and then decrypt the incoming message that has been encrypted with AES-256-CTR, using an RSA-encrypted
# session key, and an unencrypted nonce.
#
# Arguments:
#   public_key: An rsa.RSAPublicKey object containing the public key of the message sender that will be used to verify the incoming message.
#
#   signature: An RSA byte signature of the encrypted session key, nonce, and encrypted message
#   
#   private_key: An rsa.RSAPrivateKey object containing the private key that will be used to decrypt the session key.
#   
#   encrypted_session_key: The RSA-encrypted session key that will be used to decrypt the actual message with AES-256-CTR (as a raw byte string).
#   
#   nonce: The nonce that will be used to decrypt the message with AES-256-CTR (as a raw byte string).
#   
#   ciphertext: The AES-256-CTR-encrypted message (as a raw byte string).
#
# Returns: The decrypted message (plaintext) as a raw byte string
def decrypt_message(public_key:rsa.RSAPublicKey, signature, private_key, encrypted_session_key, nonce, ciphertext):
    """Again note that if your data is too large to be passed in a single call, you can hash it separately and pass that value using Prehashed."""
    #encrypt message returns a tuple containing first the RSA-encrypted session key, second the nonce used to encrypt, third the message
    #encrypted with AES-256-CTR and the session key, and fourth an RSA byte signature of the encrypted session key, nonce, and encrypted message
    #will raise an InvalidSignature exception if the signature does not match
    public_key.verify(
        signature,
        b"".join((encrypted_session_key,nonce,ciphertext)),
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH
        ),
        hashes.SHA256()
    )
    return decrypt_message_with_aes_and_rsa(private_key,encrypted_session_key,nonce,ciphertext).decode("utf-8")

def main_receive():
    recipientkeys = rsa_gen_keypair()
    HOST = " 10.17.109.66"  # Standard loopback interface address (localhost)
    PORT = 65432  # Port to listen on (non-privileged ports are > 1023)

    print('server is up')
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        print('server is up')
        s.bind((HOST, PORT))
        print('server is bound')
        s.listen()
        print('server is listening')
        conn, addr = s.accept()
        print('server is accepting requests')
        responses = []
        i = 0
        with conn:
            print(f"Connected by {addr}")
            while True:
                data = conn.recv(20000)
                if (i==0):
                    sender_pub_key = rsa_deserialize_public_key(data.decode())
                    print(sender_pub_key)
                    conn.sendall(rsa_serialize_public_key(recipientkeys.public_key()).encode())
                    i = 1
                else:
                    responses.append(data)
                if len(responses)==4:
                    print(responses)
                    plaintext2 = decrypt_message(
                    sender_pub_key,
                    responses[3],
                    recipientkeys,
                    responses[0],
                    responses[1],
                    responses[2]
                    )
                    print(plaintext2)
                    f = open('uploads/' + plaintext2.split()[0] + '.' + plaintext2.split()[1], 'a')
                    f.write(' '.join(plaintext2.split()[2:]))
                    f.close()
                    conn.sendall(b"ok")
                    message = "File received"
                    break
    return message
#given a file path converts the specified file into a string representation "fileName fileExtension fileBytes"
def filetostring(fpath):
    fname = os.path.basename(fpath)
    fstring = fname.split('.')
    with open(fpath,"r") as f: fstring.append(f.read())
    return ' '.join(fstring)

def main_send(path=""):
    senderkeys = rsa_gen_keypair()
    recipientkeys:rsa.RSAPublicKey = None
    print('sender key generated')
    #plaintext = input("enter message for sender to send to receiver: ")
    #senderkeys is the private key of the sender's key pair
    #encKey_nonce_encMes_signature = encrypt_message(senderkeys,recipientkeys.public_key(),plaintext)
    #encKey,nonce,encMes, private_key
    #print(encKey_nonce_encMes_signature[2])
    #plaintext2 = decrypt_message(
    #    senderkeys.public_key(),
    #    encKey_nonce_encMes_signature[3],
    #    recipientkeys,
    #    encKey_nonce_encMes_signature[0],
    #    encKey_nonce_encMes_signature[1],
    #    encKey_nonce_encMes_signature[2]
    #)
    #print(plaintext2)
    #print(filetostring("test.txt"))
    HOST = "10.17.109.66"  # The server's hostname or IP address
    PORT = 65432  # The port used by the server
    i = 0
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print('connection is made')
        not_sent = True
        while True:
            print('looping')
            if i == 0:
                s.sendall(rsa_serialize_public_key(senderkeys.public_key()).encode())
                data = s.recv(1024)
                recipientkeys:rsa.RSAPublicKey = rsa_deserialize_public_key(data.decode())
                print("key is received")
                i = 1
            else:
                if not_sent:
                    fpath = path
                    plaintext = filetostring(fpath)
                    encKey_nonce_encMes_signature = encrypt_message(senderkeys,recipientkeys, plaintext)
                    #encKey,nonce,encMes, signature
                    print(encKey_nonce_encMes_signature[2])
                    s.sendall(encKey_nonce_encMes_signature[0] + b' ' + encKey_nonce_encMes_signature[1])
                    
                    s.sendall(encKey_nonce_encMes_signature[2] + b' ' + encKey_nonce_encMes_signature[3])
                    
                    print('file sent')
                    not_sent = False
                print('stuck')
                data = s.recv(1024)
                print('not stuck')
                if(data.decode()=="ok"):
                    message = 'File sent'
                    break
    return message

main_send('./uploads/week_schedule.txt')


# =============================================================================
